Sube la que esta en la carpeta pterodactyl en la carpeta /var/www/pterodactyl de su vps

Como poner el footer personalizado

Abre /var/www/pterodactyl/public/esmile/footer.json

Busca
"footer": "Pterodactyl | Power by Esmile Addons",
"loginfooter": "Pterodactyl | Power by Esmile Addons"

Reemplaza el texto por lo que quieres que salga

Pterodactyl | Power by Esmile Addons

Guarda y cierra el archivo

Comando de la terminal:

cd /var/www/pterodactyl
php artisan down
php artisan migrate --seed --force
yarn build:production
php artisan config:cache
php artisan view:cache
php artisan queue:restart
php artisan up


Una vez puesto si no te carga debes usar control + f5 de 3 a 4 veces para recargar el cache de la pagina y ya te cargue correctamente.