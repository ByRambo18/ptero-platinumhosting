Automatic installation upload "files" in /var/www/pterodactyl

MANUAL INSTALLATION:


EDIT:

/var/www/pterodactyl/resources/scripts/components/NavigationBar.tsx under the

<div css={tw`mx-auto w-full flex items-center`} style={{ maxWidth: '1200px', height: '3.5rem' }}>    

ADD:

<img css={'width: 4%;'} src={'https://cdn.discordapp.com/attachments/908883160094343168/958475307197816862/ptero.png'} />  

EXCUTE COMMANDS SSH

cd /var/www/pterodactyl && yarn build:production


